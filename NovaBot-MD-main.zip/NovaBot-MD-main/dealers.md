### Aquí puedes verificar los distribuidores autorizados.
#### ✅ = Distribuidor en curso.
#### ⚪ = Sin información.
 
| USUARIO          |   CÓDIGO                | CONTACTO    | ESTADO
| ------------     | ------------            | ------------| ------------
| [**russellxz**](https://github.com/russellxz)        | ⚪ | +447700179665 | ✅
| ⚪        | ⚪               |  ⚪ | ⚪

